
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;



public class ConnectData {


    public ConnectData() {
        
        try {
                   
            Class.forName("java.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "");
            System.out.println("Connection Successfully");
        } catch (ClassNotFoundException ex) {
           //Logger.getLogger(ConnectData.class.getName()).log(Level.SEVERE, null, ex);
           ex.printStackTrace();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectData.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {

        ConnectData cd = new ConnectData();
        
    }
      
}
